//
//  VegaScrollFlowLayout.h
//  VegaScrollFlowLayout
//
//  Created by Guilherme Rambo on 14/09/17.
//  Copyright © 2017 Guilherme Rambo. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for VegaScrollFlowLayout.
FOUNDATION_EXPORT double VegaScrollFlowLayoutVersionNumber;

//! Project version string for VegaScrollFlowLayout.
FOUNDATION_EXPORT const unsigned char VegaScrollFlowLayoutVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VegaScrollFlowLayout/PublicHeader.h>


